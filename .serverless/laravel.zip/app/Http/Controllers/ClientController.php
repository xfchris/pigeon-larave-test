<?php

namespace App\Http\Controllers;

use App\Events\ClientCreateEvent;
use E4\Pigeon\Facades\Pigeon;
use Illuminate\Http\Request;

class ClientController extends Controller
{

    public function create()
    {
        $client = [
            'uuid' => 123,
            'name' => 'Chris Vale',
            'age' => 8,
            'location' => [
                    'city' => 'Cali',
                    'state' => 'Valle del Cauca',
                    'country' => 'Colombia'
                ]
            ];
        Pigeon::publish("client::create", $client);
        return $client;
    }
}
