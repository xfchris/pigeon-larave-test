<?php

namespace App\Listeners;

use App\Events\ClientUpdateEvent;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class ClientUpdateListener
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  ClientUpdateEvent  $event
     * @return void
     */
    public function handle(ClientUpdateEvent $event)
    {
        //
    }
}
