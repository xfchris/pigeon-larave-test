<?php

namespace E4\Pigeon\Exceptions;

use Exception;

class MessageBrokerConfigException extends Exception
{
}
