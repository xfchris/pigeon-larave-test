<?php

namespace E4\Pigeon\Exceptions;

use Exception;

class SignatureSignException extends Exception
{
}
