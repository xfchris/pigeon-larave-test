<?php

namespace E4\Pigeon\Exceptions;

use Exception;

class SignatureVerifyException extends Exception
{
}
